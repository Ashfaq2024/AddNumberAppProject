﻿using System;
using System.Drawing;

partial class Form1
{
    private readonly EventHandler btnCalculate_Click;
    private readonly object Controls;
    private System.ComponentModel.IContainer components = null;
    private Label lblNumber1;
    private Label lblNumber2;
    private Label lblResult;
    private TextBox textBox1;
    private TextBox textBox2;
    private Button btnCalculate;

    public Size ClientSize { get; private set; }

    private void InitializeComponent()
    {
        this.lblNumber1 = new Label();
        this.lblNumber2 = new Label();
        this.lblResult = new Label();
        this.textBox1 = new TextBox();
        this.textBox2 = new TextBox();
        this.btnCalculate = new Button();

        // 
        // lblNumber1
        // 
        this.lblNumber1.Text = "Enter Number 1:";
        this.lblNumber1.Location = new System.Drawing.Point(20, 20);
        // 
        // lblNumber2
        // 
        this.lblNumber2.Text = "Enter Number 2:";
        this.lblNumber2.Location = new System.Drawing.Point(20, 60);
        // 
        // lblResult
        // 
        this.lblResult.Location = new System.Drawing.Point(20, 140);
        this.lblResult.Size = new System.Drawing.Size(100, 20);
        // 
        // textBox1
        // 
        this.textBox1.Location = new System.Drawing.Point(140, 20);
        this.textBox1.Name = "textBox1";
        this.textBox1.Size = new System.Drawing.Size(100, 20);
        // 
        // textBox2
        // 
        this.textBox2.Location = new System.Drawing.Point(140, 60);
        this.textBox2.Name = "textBox2";
        this.textBox2.Size = new System.Drawing.Size(100, 20);
        // 
        // btnCalculate
        // 
        this.btnCalculate.Text = "Calculate";
        this.btnCalculate.Location = new System.Drawing.Point(140, 100);
        this.btnCalculate.Click += new EventHandler(this.btnCalculate_Click);

        // 
        // Form1
        // 
        this.Controls.Add(this.lblNumber1);
        this.Controls.Add(this.lblNumber2);
        this.Controls.Add(this.lblResult);
        this.Controls.Add(this.textBox1);
        this.Controls.Add(this.textBox2);
        this.Controls.Add(this.btnCalculate);
        this.ClientSize = new System.Drawing.Size(300, 200);
        this.textBox1 = "Add Numbers";
    }
}


