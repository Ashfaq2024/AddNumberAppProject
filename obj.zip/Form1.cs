﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace AddNumbersApp
{

    public partial class Form1 : Form
    {
        public Label lblNumber1 { get; private set; }
        public object textBox2 { get; private set; }
        public object textBox1 { get; private set; }
        public object lblResult { get; private set; }
        public object resultLabel { get; private set; }

        private void InitializeComponent()
        {
            this.lblNumber1 = new System.Windows.Forms.Label();
            // Other controls initialization here...
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            // Code to run when the form is loaded (optional)
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            // Convert text in textboxes to numbers
            double number1 = double.Parse(textBox1.Text);
            double number2 = double.Parse(textBox2.Text);

            // Add numbers
            double result = number1 + number2;

            // Display result in the label
            lblResult.Text = "Result: " + result.ToString();
        }


        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            // Handle the logic when text in TextBox1 changes
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Handle button click to add the numbers
            double num1 = Convert.ToDouble(textBox1.Text);
            double num2 = Convert.ToDouble(textBox2.Text);
            double sum = num1 + num2;

            // Display the result in a label
            resultLabel.Text = "Result: " + sum.ToString();
        }
        private void buttonAdd_Click(object sender, EventArgs e)
        {
            double num1, num2, sum;
            if (double.TryParse(textBox1.Text, out num1) && double.TryParse(textBox2.Text, out num2))
            {
                sum = num1 + num2;
                resultLabel.Text = "Sum: " + sum.ToString();
            }
            else
            {
                resultLabel.Text = "Please enter valid numbers!";
            }
        }

    }
}